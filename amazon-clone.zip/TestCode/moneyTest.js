import { formatCurrency } from "../../utils/money.js";

console.log('is 2095 = 20.95 :');
if(formatCurrency(2095) === '20.95'){
 console.log('Passed!');
}else {
 console.log('fail!');
}

console.log('is 0 = 0.00 :');
if(formatCurrency(0) === '0.00'){
 console.log('Passed!');
}else {
 console.log('fail!');
}

console.log('is 20005 = 20.01 :');
if(formatCurrency(20005) === '20.01'){
 console.log('Passed!');
}else {
 console.log('fail!');
}

console.log('is 20006 = 20.01 :');
if(formatCurrency(20009) === '20.01'){
 console.log('Passed!');
}else {
 console.log('fail!');
}