import { calculateCartQuantity } from '../../data/cart.js';

export function checkoutHeader() {
  const totalQuantity = calculateCartQuantity();
  const header = document.querySelector('.js-checkout-section');

  if (header) {
    header.innerHTML = `Checkout (<a class="return-to-home-link" href="amazon.html">${totalQuantity} Items</a>)`;
  }
}
