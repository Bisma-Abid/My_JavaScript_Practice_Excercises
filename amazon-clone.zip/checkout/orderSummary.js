import { cart, removeCart, updateQuantity, updateDeliveryOptions } from '../../data/cart.js';
import { getProduct } from '../../data/products.js';
import { deliveryOptions, getDeliveryOption } from '../../data/deliveryOptions.js';
import { formatCurrency } from '../utils/money.js';
import { renderPaymentSummary } from './paymentSummary.js';
import { checkoutHeader } from './checkoutHeader.js';
import dayjs from 'https://unpkg.com/supersimpledev@8.5.0/dayjs/esm/index.js';

export function renderOrderSummary() {
  let cartOrderSummary = '';

  cart.forEach((cartItem) => {
    const product = getProduct(cartItem.productId);
    if (!product) {
      console.warn('Product not found for ID:', cartItem.productId);
      return;
    }

    const deliveryOption = getDeliveryOption(cartItem.deliveryOptionId);
    const deliveryDate = dayjs().add(deliveryOption.deliveryDays, 'days');
    const formattedDate = deliveryDate.format('dddd, MMMM D');

    cartOrderSummary += `
      <div class="cart-item-container js-container-${product.id}">
        <div class="delivery-date">Delivery date: ${formattedDate}</div>

        <div class="cart-item-details-grid">
          <img class="product-image" src="${product.image}">

          <div class="cart-item-details">
            <div class="product-name">${product.name}</div>
            <div class="product-price">$${formatCurrency(product.priceCents)}</div>

            <div class="product-quantity">
              <span class="js-quantity">
                Quantity: <span class="quantity-label">${cartItem.quantity}</span>
              </span>
              <span class="update-quantity-link link-primary js-update-link">Update</span>
              <input class="js-update-input" />
              <span class="js-save-button">Save</span>
              <br>
              <span class="delete-quantity-link link-primary js-link-delete" data-product-id="${product.id}">Delete</span>
            </div>
          </div>

          <div class="delivery-options">
            <div class="delivery-options-title">Choose a delivery option:</div>
            ${deliveryOptionsHTML(product, cartItem)}
          </div>
        </div>
      </div>
    `;
  });

  document.querySelector('.js-order-summary').innerHTML = cartOrderSummary;

  document.querySelectorAll('.js-link-delete').forEach((link) => {
    link.addEventListener('click', () => {
      const productId = link.dataset.productId;
      removeCart(productId);
      const container = document.querySelector(`.js-container-${productId}`);
      if (container) container.remove();
      refreshCartUI();
    });
  });

  document.querySelectorAll('.js-update-link').forEach((link) => {
    link.addEventListener('click', () => {
      const container = link.closest('.cart-item-container');
      if (container) {
        container.classList.add('is-editing-quantity');
        const input = container.querySelector('.js-update-input');
        const save = container.querySelector('.js-save-button');
        input.style.display = 'inline-block';
        save.style.display = 'inline-block';
      }
    });
  });

  document.querySelectorAll('.js-save-button').forEach((button) => {
    button.addEventListener('click', () => {
      const container = button.closest('.cart-item-container');
      const input = container.querySelector('.js-update-input');
      const quantityLabel = container.querySelector('.quantity-label');

      const newQuantity = Number(input.value);
      if (isNaN(newQuantity) || newQuantity <= 0) {
        alert('Please enter a valid quantity.');
        return;
      }

      const productId = container.classList.value.match(/js-container-(.+?)\b/)[1];

      updateQuantity(productId, newQuantity);
      quantityLabel.innerText = newQuantity;
      container.classList.remove('is-editing-quantity');
      input.style.display = '';
      button.style.display = '';
      refreshCartUI();
    });
  });

  document.querySelectorAll('.js-delivery-option').forEach((element) => {
    element.addEventListener('click', () => {
      const { productId, deliveryOptionId } = element.dataset;
      updateDeliveryOptions(productId, deliveryOptionId);
      renderOrderSummary();
      refreshCartUI();
    });
  });
}

function deliveryOptionsHTML(product, cartItem) {
  return deliveryOptions.map((option) => {
    const deliveryDate = dayjs().add(option.deliveryDays, 'days').format('dddd, MMMM D');
    const isChecked = option.id === cartItem.deliveryOptionId;
    const price = option.priceCents === 0 ? 'FREE' : `$${formatCurrency(option.priceCents)}`;

    return `
      <div class="delivery-option js-delivery-option"
        data-product-id="${product.id}"
        data-delivery-option-id="${option.id}">
        <input type="radio" ${isChecked ? 'checked' : ''} name="delivery-option-${product.id}" class="delivery-option-input" />
        <div>
          <div class="delivery-option-date">${deliveryDate}</div>
          <div class="delivery-option-price">${price}</div>
        </div>
      </div>
    `;
  }).join('');
}

function refreshCartUI() {
  checkoutHeader();
  renderPaymentSummary();
}
