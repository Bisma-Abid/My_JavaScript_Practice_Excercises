import { cart, calculateCartQuantity } from '../../data/cart.js';
import { getProduct } from '../../data/products.js';
import { getDeliveryOption } from '../../data/deliveryOptions.js';
import { formatCurrency } from '../utils/money.js';

export function renderPaymentSummary() {
  let productPriceCents = 0;
  let shippingPriceCents = 0; // ✅ Always start from 0

  // Calculate product total and shipping total
  cart.forEach((cartItem) => {
    const product = getProduct(cartItem.productId);
    if (!product) return;

    productPriceCents += product.priceCents * cartItem.quantity;

    const deliveryOption = getDeliveryOption(cartItem.deliveryOptionId);
    if (deliveryOption) {
      shippingPriceCents += deliveryOption.priceCents;
    }
  });

  const totalBeforeTaxCents = productPriceCents + shippingPriceCents;
  const taxCents = totalBeforeTaxCents * 0.1;
  const totalCents = totalBeforeTaxCents + taxCents;

  // Build summary HTML
  const paymentSummaryHTML = `
    <div class="payment-summary-title">
      Order Summary
    </div>

    <div class="payment-summary-row">
      <div class="js-summary-row"></div>
      <div class="payment-summary-money">$${formatCurrency(productPriceCents)}</div>
    </div>

    <div class="payment-summary-row">
      <div>Shipping &amp; handling:</div>
      <div class="payment-summary-money">$${formatCurrency(shippingPriceCents)}</div>
    </div>

    <div class="payment-summary-row subtotal-row">
      <div>Total before tax:</div>
      <div class="payment-summary-money">$${formatCurrency(totalBeforeTaxCents)}</div>
    </div>

    <div class="payment-summary-row">
      <div>Estimated tax (10%):</div>
      <div class="payment-summary-money">$${formatCurrency(taxCents)}</div>
    </div>

    <div class="payment-summary-row total-row">
      <div>Order total:</div>
      <div class="payment-summary-money">$${formatCurrency(totalCents)}</div>
    </div>

    <button  class="place-order-button button-primary">
     <a style="text-decoration:none;font-size:1.2rem;color:black;font-weight:900" href="orders.html">Place your order</a>
    </button>
  `;

  // Inject HTML into the DOM
  const container = document.querySelector('.js-payment-summary');
  if (container) {
    container.innerHTML = paymentSummaryHTML;
    updateCartQuantity(); // ✅ Only call this after HTML is inserted
  } else {
    console.warn('Element with class `.js-payment-summary` not found.');
  }
}

// Updates the quantity row (Items X)
function updateCartQuantity() {
  const totalQuantity = calculateCartQuantity();
  const summaryRow = document.querySelector('.js-summary-row');
  if (summaryRow) {
    summaryRow.innerHTML = `Items (${totalQuantity})`;
  } else {
    console.warn('Element with class `.js-summary-row` not found.');
  }
}
