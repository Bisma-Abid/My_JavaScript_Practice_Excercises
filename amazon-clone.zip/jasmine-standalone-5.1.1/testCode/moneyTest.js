import { formatCurrency } from "../../utils/money.js";

describe('test Suite : FormatFrequency', () => {
   it('check no , as 2095 it equal to 20.95',() =>{
      expect(formatCurrency(2095)).toEqual('20.95');
   });
   it('check no , as 0 it equal to 0.00',() =>{
      expect(formatCurrency(0)).toEqual('0.00');
   });
   it('check no , as 2345 it equal to 23.45',() =>{
      expect(formatCurrency(2345)).toEqual('23.45');
   });
   it('check no , as 20005 it equal to 20.01',() =>{
      expect(formatCurrency(20005)).toEqual('20.01');
   });
});


