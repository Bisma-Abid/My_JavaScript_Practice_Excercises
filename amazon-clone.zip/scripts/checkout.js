import {renderPaymentSummary} from '../checkout/paymentSummary.js'
import {renderOrderSummary} from '../checkout/orderSummary.js';

renderPaymentSummary();
renderOrderSummary();