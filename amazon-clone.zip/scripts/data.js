import { cart, addToCart, calculateCartQuantity } from '../data/cart.js';
import { products } from '../data/products.js';

let productContainer = ``;

products.forEach((product) => {
  productContainer += `
    <div class="product-container">
      <div class="product-image-container">
        <img class="product-image" src="${product.image}">
      </div>

      <div class="product-name limit-text-to-2-lines">
        ${product.name}
      </div>

      <div class="product-rating-container">
        <img class="product-rating-stars"
          src="images/ratings/rating-${product.rating.stars * 10}.png" />
        <div class="product-rating-count link-primary">
          ${product.rating.count}
        </div>
      </div>

      <div class="product-price">
        $${(product.priceCents / 100).toFixed(2)}
      </div>

    <div class="product-quantity-container">
  <input type="number"
         class="js-product-quantity"
         data-product-id="${product.id}"
         value="1"
         min="1"
         max="999"
         style="width: 50px; text-align: center;" />
   </div>


      <div class="product-spacer"></div>

      <div class="added-to-cart" >
        <img src="images/icons/checkmark.png">
        Added
      </div>

      <button class="add-to-cart-button button-primary js-cart" data-product-id="${product.id}">
        Add to Cart
      </button>
    </div>`;
});

document.querySelector('.js-grid').innerHTML = productContainer;

updateCartQuantity(); // ✅ Call it on load

function updateCartQuantity() {
  const totalQuantity = calculateCartQuantity();
  document.querySelector('.js-quantity').innerHTML = totalQuantity;
}

document.querySelectorAll('.js-cart').forEach((button) => {
  button.addEventListener('click', () => {
    const productId = button.dataset.productId;

    const input = document.querySelector(`.js-product-quantity[data-product-id="${productId}"]`);
    let quantity = parseInt(input.value);

    // ✅ Validate input
    if (isNaN(quantity) || quantity < 1 || quantity > 999) {
      alert('Please enter a quantity between 1 and 999.');
      input.value = 1;
      return;
    }

    addToCart(productId, quantity);
    updateCartQuantity();

    const productContainer = button.closest('.product-container');
    const addedMsg = productContainer.querySelector('.added-to-cart');
    addedMsg.style.display = 'block';

    setTimeout(() => {
      addedMsg.style.display = 'none';
    }, 1500);
  });
});


// Set quantity dropdowns according to what's in cart
document.querySelectorAll('.js-product-quantity').forEach((select) => {
  const productId = select.dataset.productId;
  const cartItem = cart.find(item => item.productId === productId);
  if (cartItem) {
    select.value = cartItem.quantity;
  }
});

