import { cart, calculateCartQuantity} from '../../data/cart.js';
import { getProduct } from '../../data/products.js';
import { getDeliveryOption } from '../../data/deliveryOptions.js';
import { formatCurrency } from '../utils/money.js';
import dayjs from 'https://unpkg.com/supersimpledev@8.5.0/dayjs/esm/index.js';

const ordersContainer = document.querySelector('.js-order-summary');




if (cart.length === 0) {
  ordersContainer.innerHTML = '<p style="text-align:center;">No orders placed yet.</p>';
} else {
  let html = '';

  cart.forEach((cartItem) => {
    const product = getProduct(cartItem.productId);
    const deliveryOption = getDeliveryOption(cartItem.deliveryOptionId);
    const deliveryDate = dayjs().add(deliveryOption.deliveryDays, 'days').format('dddd, MMMM D');

    html += `
      <div style="background-color:rgb(255, 237, 240)" class="order-container">
        <div style="height:70px;padding-top:50px;font-size:1.3rem;background-color:#f0c14b;padding-left:50px;padding-right:50px" class="order-header">
          <div>
            <div class="order-header-label">Order Placed:</div>
            <div>${dayjs().format('MMMM D')}</div>
          </div>
          <div>
            <div class="order-header-label">Order ID:</div>
            <div>#${Math.floor(Math.random() * 100000000)}</div>
          </div>
          <div>
            <div class="order-header-label">Total:</div>
            <div>$${formatCurrency(product.priceCents * cartItem.quantity)}</div>
          </div>
        </div>

        <div class="order-item">
          <div class="product-image-container">
            <img src="${product.image}" alt="${product.name}">
          </div>
          <div class="product-details">
            <div class="product-name">${product.name}</div>
            <div class="product-delivery-date">Arriving on: ${deliveryDate}</div>
            <div class="product-quantity">Quantity: ${cartItem.quantity}</div>
          </div>
          <div class="product-actions">
            <button class="buy-again-button"><a style="text-decoration:none;font-size:1.1rem;color:black;font-weight:400" href="index.html">Buy Again</a></button>
            <button class="track-package-button"><a style="text-decoration:none;font-size:1rem;color:black;font-weight:400" href="tracking.html">Track Package</a></button>
          </div>
        </div>
      </div>
    `;
  });

  ordersContainer.innerHTML = html;
}

updateCartQuantity(); // ✅ Call it on load

function updateCartQuantity() {
  const totalQuantity = calculateCartQuantity();
  document.querySelector('.js-quantity').innerHTML = totalQuantity;
}
