// tracking.js
import { cart, calculateCartQuantity } from '../../data/cart.js';
import { getProduct } from '../../data/products.js';
import { getDeliveryOption } from '../../data/deliveryOptions.js';
import dayjs from 'https://unpkg.com/supersimpledev@8.5.0/dayjs/esm/index.js';

const trackingContainer = document.querySelector('.order-tracking');

if (!cart.length) {
  trackingContainer.innerHTML = `
    <p style="text-align:center; font-size: 1.2rem;">You have no recent deliveries to track.</p>
  `;
} else {
  let trackingHTML = `
    <a class="back-to-orders-link link-primary" href="orders.html">
      View all orders
    </a>
  `;

  cart.forEach((item) => {
    const product = getProduct(item.productId);
    const deliveryOption = getDeliveryOption(item.deliveryOptionId);
    const deliveryDate = dayjs().add(deliveryOption.deliveryDays, 'days').format('dddd, MMMM D');

    trackingHTML += `
      <div style="background-color:#c8c6c6;padding:50px" class="tracking-card">
        <div class="delivery-date">Arriving on ${deliveryDate}</div>
        <div class="product-info">${product.name}</div>
        <div class="product-info">Quantity: ${item.quantity}</div>
        <img class="product-image" src="../../${product.image}" alt="${product.name}">


        <div class="progress-labels-container">
          <div class="progress-label">Preparing</div>
          <div class="progress-label current-status">Shipped</div>
          <div class="progress-label">Delivered</div>
        </div>

        <div class="progress-bar-container">
          <div class="progress-bar shipped"></div>
        </div>
      </div><br><br>
    `;
  });

  trackingContainer.innerHTML = trackingHTML;
}

updateCartQuantity();

function updateCartQuantity() {
  const totalQuantity = calculateCartQuantity();
  const cartQuantityEl = document.querySelector('.cart-quantity');
  if (cartQuantityEl) {
    cartQuantityEl.innerText = totalQuantity;
  }
}
